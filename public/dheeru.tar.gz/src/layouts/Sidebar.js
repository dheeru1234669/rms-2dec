import React from 'react';

export default class Sidebar extends React.Component{

	constructor(props){
		super(props);
	}

	render(){
		return(
        <div className='container-fuild'>
            <div className='row'>
                <div className='sidebar'>
        <ul className='navbar-nav sidebar-ul'>
            <li className='nav-item sidebar-li'><a href="/"className='nav-link'>Home</a></li>
            <li className='nav-item sidebar-li '><a href="/Overview" className='nav-link'>Menu</a></li>
            <li className='nav-item sidebar-li'><a href="/ProfileOverview" className='nav-link'>Profile</a></li>
            <li className='nav-item sidebar-li'><a href="/TableOverview"className='nav-link'>Table Management</a></li>
            <li className='nav-item sidebar-li'><a href="/Designtheme"className='nav-link'>Design</a></li>
            <li className='nav-item sidebar-li'><a href="/StartOrderPop"className='nav-link'>Reports</a></li>
            <li className='nav-item sidebar-li'><a href="/"className='nav-link'>Analytics</a></li>
            <li className='nav-item sidebar-li'><a href="/Dashboardwaiter"className='nav-link'>Dashboard</a></li>
            <li className='nav-item sidebar-li'><a href="/"className='nav-link'>Settings</a></li>
        </ul>
     </div>
            </div>
        </div>
     
    
        )
	}
		
}
