import React from 'react';
import { Modal, ModalFooter, ModalHeader, ModalBody, Button } from 'reactstrap'

import { Header, Sidebar } from '../../../src';


export default class Home extends React.Component{

    constructor(props){
        super(props);
        this.state = {data:[], prnt_data:[], modal:!1}
    }

    componentDidMount(){
        this._apiCall();
    }

    async _apiCall(){
        var url = '/admin/cat-and-item' 
        var res = await app.get(url)

        if(res.status){
            this.setState({data:res.data})
        }
    }

  
    modelOpen(e){
        console.log("test==")
        this.toggleModal(e)
    }
                        
   toggleModal = () => { this.setState({modal:!this.state.modal}); };


    render(){
        var {data, prnt_data} = this.state;

        return (
                <>
                <div className="container-fluid">
                <div className='row'>
                <Header/>
                </div>
                <div className='row'>
                <div className='col-md-2'>
                <Sidebar/>
                </div>
                <div className='col-lg-10 p-0'>
                <div className='wraper pb-5'>
                <div className="d-flex justify-content-between">
                <div className='builder'>
                <h5 className='menu-item fw-bold mb-4 mt-4'>Menu Builder</h5>
                </div>
                <div className='builder'>
                <button className='menu-item btn-radius mb-4 mt-4' href="javascript:void(0);" onClick={(event)=>this.modelOpen(event)}>Add a menu category<span className='btn-icon'><i className="fa fa-plus fw-normal" aria-hidden="true"></i></span></button>
                </div>
                </div>
                <div className="drop">
                {/* //drink */}
               

        {data.map((parent) => { // rendering parent data
                return (
                        <div className="drop_container" id="drop-items">
                            <div className="drop_card main-category w-100">
                                <div className="drop_data">
                                    <div className='d-flex justify-content-between drop-item p-2'>
                                        <div className='builder'>
                                            <h3 className='heading'>{parent.name}</h3>
                                        </div>
                                        <div className='builder'>
                                            <button className='menu-item right btn-radius'data-bs-toggle="modal" href="#myModal">Customize</button>
                                            <button className='menu-item btn-radius'data-bs-toggle="modal" href="javascript:void(0);" onClick={(event)=>this.modelOpen(event)}>Add a sub category<span className='btn-icon'><i className="fa fa-plus fw-normal" aria-hidden="true"></i></span></button>
                                            <img src="../../assets/images/icon-drag-drop.png" className="dragdrop-icon"/>

                                        </div>
                                    </div>
                                </div>
                            </div>



                        {parent.children.map((child) => { // rendering children of the parent
                                return (
                                        <div>


                                        <div className="drop_card sub-category mt-3">
                                            <div className="drop_data">
                                                <div className='d-flex justify-content-between drop-item p-2'>
                                                    <div className='builder'>
                                                        <h3 className='heading'>{child.name}</h3>
                                                    </div>
                                                    <div className='builder'>
                                                        <button className='menu-item right btn-radius'data-bs-toggle="modal" href="#myModal">Customize</button>
                                                        <button className='menu-item btn-radius'data-bs-toggle="modal" href="#myModal">Add a sub-sub category<span className='btn-icon'><i className="fa fa-plus fw-normal" aria-hidden="true"></i></span></button>
                                                        <img src="../../assets/images/icon-drag-drop.png" className="dragdrop-icon"/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>



                                        {child.children && // rendering grandchildren of the parent
                                        child.children.map((grandChild) => {
                                                return (
                                                        <div
                                                        key={grandChild.name}
                                                        style={{ paddingLeft: "20px" }}
                                                        >

                                                    <div className="drop_card sub-sub-cate mt-3">
                                                        <div className="drop_data">
                                                            <div className='d-flex justify-content-between drop-item p-2'>
                                                                <div className='builder'>
                                                                    <h3 className='heading'>{grandChild.name}</h3>
                                                                </div>
                                                                <div className='builder'>
                                                                    <button className='menu-item right btn-radius'data-bs-toggle="modal" href="#myModal">Customize</button>  
                                                                    <button className='menu-item btn-radius'data-bs-toggle="modal" href="#Createitempop">Create item<span className='btn-icon'><i className="fa fa-plus fw-normal" aria-hidden="true"></i></span></button>
                                                                    <img src="../../assets/images/icon-drag-drop.png" className="dragdrop-icon"/>
                                                                </div>
                                                            </div>
                                                            <hr className='m-0'></hr>
                                                            <div className='d-flex justify-content-between drop-item p-2'>
                                                                <div className='builder-product'>
                                                                    <div className='img-builder'>
                                                                        <img src="../../assets/images/coca.PNG" className="img-item"/>
                                                                    </div>
                                                                    <span className='item-name'>Coca-Cola Zero</span>
                                                                </div>
                                                                <div className='builder'>
                                                                    <h3 className='item-price'>From R23.90<span> <img src="../../assets/images/icon-drag-drop.png" className="dragdrop-icon"/></span></h3>
                                                                </div>
                                                            </div>
                                                            <hr className='m-0'></hr>
                                                            <div className='d-flex justify-content-between drop-item p-2'>
                                                                <div className='builder-product'>
                                                                    <div className='img-builder'>
                                                                        <img src="../../assets/images/coca.PNG" className="img-item"/>
                                                                    </div>
                                                                    <span className='item-name'>Red Bull</span>
                                                                </div>
                                                                <div className='builder'>
                                                                    <h3 className='item-price'> <span className='eye-icon'><i className="fa fa-eye-slash" aria-hidden="true"></i></span> R29.90<span> <img src="../../assets/images/icon-drag-drop.png" className="dragdrop-icon"/></span></h3>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>


                                                        




                                                        {grandChild.children && // rendering great-grandchildren
                                                        grandChild.children.map((greatGrandChild) => {
                                                                return (
                                                                        <div
                                                                        key={greatGrandChild.name}
                                                                        style={{ paddingLeft: "20px" }}
                                                                        >
                                                                        <span>{greatGrandChild.name}</span>
                                                                        </div>
                                                                       );
                                                                })}
                                                        </div>
                                                       );
                                                })}
                                        </div>
                                            );
                                                        })}
                </div>
                    );
                              })}





        
                



                    {/* food */}
        
            </div>
            </div>
            </div>
            </div>
            </div>




        {/* Start Add/Edit Category Modal */}
            
          <Modal isOpen={this.state.modal}
            toggle={this.toggleModal}
            modalTransition={{ timeout: 200 }}
            className="cstModal">

          <ModalBody>
            <div>
                <input type="email" className="form-control date-time w-50"placeholder="Drinks"/>
            </div>
            <div className="modal-body border border-0">
                <div className="flex justify-center h-screen items-center">
                    <div className="rounded-lg shadow-xl bg-gray-50 md:w-1/2 w-[360px]">
                        <div className="flex items-center justify-center w-full upload-docu border border-secondary">
                            <label className="flex justify-content-center w-100">
                                <div className="flex flex-col items-center justify-center mt-3 upload-img">
                                    <p className=" text-sm tracking-wider text-center text-dark fw-bold text-secondary">Click to upload image</p>
                                </div>
                                <input type="file" className="opacity-0" />
                            </label>
                            <div className='popup-icon-delete'>
                                <img src="../assest/images/icon-delete.png" className="delete-pop-icon"/>
                            </div>
                        </div>
                        <p className='peragraph pt-2'>Header image should be 1600px X 350px and in
.png or .jpeg images.</p>
                        <div className="form-check">
                            <input type="radio" className="form-check-input" id="radio1" name="optradio" value="option1" checked/><span className='peragraph'>Use an image header</span>
                            <label className="form-check-label" for="radio1"></label>
                        </div>
                        <div className="form-check">
                            <input type="radio" className="form-check-input" id="radio2" name="optradio" value="option2"/><span className='peragraph'>Use text as header</span>
                            <label className="form-check-label" for="radio2"></label>
                        </div>
                        <hr></hr>
<form action="/action_page.php">
<div className="form-check">
  <input type="checkbox" className="form-check-input" id="check1" name="option1" value="something"/>
  <label className="form-check-label" for="check1"><span className='peragraph'>Hidden category (items are still usable) </span></label>
</div>
<div className="form-check">
  <input type="checkbox" className="form-check-input" id="check2" name="option2" value="something"/>
  <label className="form-check-label" for="check2"><span className='peragraph'>Enable time based visibility</span></label>
</div>
<div className='row'>
  <div className='col-sm-6'>
  <label className="form-check-label"><span className='peragraph'>Enable time based visibility</span></label>
  <select className="form-select date-time">
<option>Every Day</option>
<option>One Day</option>
</select>
  </div>
  <div className='col-sm-3'>
  <label className="form-check-label"><span className='peragraph'>Start</span></label>
  <input type="text" className="form-control date-time" placeholder="00:00"/>
    </div>
    <div className='col-sm-3'>
    <label className="form-check-label"><span className='peragraph'>End</span></label>
    <input type="text" className="form-control date-time" placeholder="00:00"/>
    </div>
</div>
</form>
</div>
</div>
</div>
<button className='btn-radius mt-2'>Add<span className='btn-icon'><i className="fa fa-plus fw-normal" aria-hidden="true"></i></span></button>
<div className='d-flex justify-content-between mt-4'>
<div className='builder'>
<button className='menu-item right btn-radius pink-btn'data-bs-toggle="modal" href="#myModal2">Delete</button>

</div>
<div className='builder'>
<button className='menu-item right btn-radius text-secondary border border-secondary'>Cancel</button>
<button className='menu-item right btn-radius green-btn'>Apply</button>
</div>
</div>
</ModalBody>
               </Modal>

{/* End add/edit category modal */}


                                                                                                                                                                                                                        </>
                                                                                                                                                                                                                        )


    }

}//
