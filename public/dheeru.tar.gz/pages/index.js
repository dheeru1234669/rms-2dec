import React from 'react';
import {Form, Button} from 'react-bootstrap';

import { ToastContainer } from 'react-toastify';

export default class Home extends React.Component{

    constructor(props){
        super(props);
        this.state = {value:''};
    }	

    async handleSubmit(e){
        e.preventDefault()
        var fd = new FormData(e.target)
        var res = await app.post('/admin/login',fd);
        if(!res.status)
        {
            app.toast(res.message, 'warning');
            return false;			
        }


        if(res.status)
        {
            sessionStorage.setItem('rms_token',res.data.token);
            sessionStorage.setItem('rms_admin_info',JSON.stringify(res.data));
            e.target.reset();
            location.href = 'admin/dashboard';

        }

    }

    render(){
        return(
                <>
                <div className="container-fluid">
                <div className='row'>
                <div className="container">
                <h1 className="form-heading">login Form</h1>
                <div className='container'>
                <div className='row'>
                <div className='col-md-5 mx-auto p-3'>
                <div className="login-form">
                <div className="main-div mx-auto">
                <div className="panel">
                <h2>Admin Login</h2>
                <p>Please enter your email and password</p>
                </div>
                <form method="post" onSubmit={(event)=>this.handleSubmit(event)}>
                <div className="form-group">
                <input type="email" className="form-control" placeholder="Email Address" id="email" aria-describedby="email" name="email" required/>
                </div>
                <div className="form-group">
                <input type="password" className="form-control" id="password" name="password" placeholder="Password"/>
                </div>
                
                <button type="submit" className="btn btn-primary">Login</button>

                </form>
                </div>
                </div></div></div>
                </div>
                </div>
                </div>
                </div>


                </>
                )
                } 

}
